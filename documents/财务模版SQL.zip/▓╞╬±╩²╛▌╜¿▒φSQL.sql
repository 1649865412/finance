/*
SQLyog Ultimate v11.42 (32 bit)
MySQL - 5.5.38-0ubuntu0.14.04.1 : Database - finance
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `area_info` */

CREATE TABLE `area_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `area_name` varchar(100) DEFAULT NULL COMMENT '地区名称',
  `area_level` bigint(10) DEFAULT NULL COMMENT '地区级别',
  `area_type` varchar(25) DEFAULT NULL COMMENT '地区类型',
  `area_id` bigint(20) DEFAULT NULL COMMENT '地区ID',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `update_time` datetime DEFAULT NULL COMMENT '数据更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='地区表';

/*Table structure for table `base_component_resource` */

CREATE TABLE `base_component_resource` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `file` longblob,
  `name` varchar(128) DEFAULT NULL,
  `size` varchar(32) DEFAULT NULL,
  `store_type` varchar(16) DEFAULT NULL,
  `upload_time` datetime DEFAULT NULL,
  `uuid` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_uuid` (`uuid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

/*Table structure for table `base_data_control` */

CREATE TABLE `base_data_control` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `control` varchar(10240) DEFAULT NULL,
  `description` varchar(256) DEFAULT NULL,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

/*Table structure for table `base_dictionary` */

CREATE TABLE `base_dictionary` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `priority` int(11) NOT NULL,
  `type` varchar(16) DEFAULT NULL,
  `value` varchar(128) DEFAULT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK468568E35EF052B` (`parent_id`) USING BTREE,
  CONSTRAINT `FK468568E35EF052B` FOREIGN KEY (`parent_id`) REFERENCES `base_dictionary` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

/*Table structure for table `base_log_info` */

CREATE TABLE `base_log_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_time` datetime DEFAULT NULL,
  `ip_address` varchar(16) DEFAULT NULL,
  `log_level` varchar(16) DEFAULT NULL,
  `message` varchar(256) DEFAULT NULL,
  `username` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13266 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

/*Table structure for table `base_module` */

CREATE TABLE `base_module` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(256) DEFAULT NULL,
  `description` varchar(256) DEFAULT NULL,
  `name` varchar(64) NOT NULL,
  `priority` int(11) NOT NULL,
  `sn` varchar(32) NOT NULL,
  `url` varchar(256) NOT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  `extend_index` varchar(255) DEFAULT NULL COMMENT '扩展首页',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_sn` (`sn`) USING BTREE,
  KEY `FK89A04864953FE581` (`parent_id`) USING BTREE,
  CONSTRAINT `FK89A04864953FE581` FOREIGN KEY (`parent_id`) REFERENCES `base_module` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

/*Table structure for table `base_organization` */

CREATE TABLE `base_organization` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(256) DEFAULT NULL,
  `name` varchar(64) NOT NULL,
  `priority` int(11) NOT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_name` (`name`) USING BTREE,
  KEY `FKCAE6352BF464A488` (`parent_id`) USING BTREE,
  CONSTRAINT `FKCAE6352BF464A488` FOREIGN KEY (`parent_id`) REFERENCES `base_organization` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

/*Table structure for table `base_organization_role` */

CREATE TABLE `base_organization_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `priority` int(11) NOT NULL,
  `organization_id` bigint(20) DEFAULT NULL,
  `role_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKD483870AC80E875F` (`organization_id`) USING BTREE,
  KEY `FKD483870A3FFD717F` (`role_id`) USING BTREE,
  CONSTRAINT `FKD483870A3FFD717F` FOREIGN KEY (`role_id`) REFERENCES `base_role` (`id`),
  CONSTRAINT `FKD483870AC80E875F` FOREIGN KEY (`organization_id`) REFERENCES `base_organization` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

/*Table structure for table `base_permission` */

CREATE TABLE `base_permission` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(256) DEFAULT NULL,
  `name` varchar(64) NOT NULL,
  `sn` varchar(16) NOT NULL,
  `module_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKCAE8ABC7BD56587F` (`module_id`) USING BTREE,
  CONSTRAINT `FKCAE8ABC7BD56587F` FOREIGN KEY (`module_id`) REFERENCES `base_module` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=308 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

/*Table structure for table `base_role` */

CREATE TABLE `base_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(256) DEFAULT NULL,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

/*Table structure for table `base_role_permission` */

CREATE TABLE `base_role_permission` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `permission_id` bigint(20) DEFAULT NULL,
  `role_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9B6EA402BB04F1F` (`permission_id`) USING BTREE,
  KEY `FK9B6EA403FFD717F` (`role_id`) USING BTREE,
  CONSTRAINT `FK9B6EA402BB04F1F` FOREIGN KEY (`permission_id`) REFERENCES `base_permission` (`id`),
  CONSTRAINT `FK9B6EA403FFD717F` FOREIGN KEY (`role_id`) REFERENCES `base_role` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1410 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

/*Table structure for table `base_role_permission_data_control` */

CREATE TABLE `base_role_permission_data_control` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `data_control_id` bigint(20) DEFAULT NULL,
  `role_permission_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKB2EFD96750319A20` (`data_control_id`) USING BTREE,
  KEY `FKB2EFD96758F6F1AC` (`role_permission_id`) USING BTREE,
  CONSTRAINT `FKB2EFD96750319A20` FOREIGN KEY (`data_control_id`) REFERENCES `base_data_control` (`id`),
  CONSTRAINT `FKB2EFD96758F6F1AC` FOREIGN KEY (`role_permission_id`) REFERENCES `base_role_permission` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

/*Table structure for table `base_user` */

CREATE TABLE `base_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_time` datetime DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `password` varchar(64) NOT NULL,
  `phone` varchar(32) DEFAULT NULL,
  `realname` varchar(32) NOT NULL,
  `salt` varchar(32) NOT NULL,
  `status` varchar(16) NOT NULL,
  `username` varchar(32) NOT NULL,
  `organization_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_name` (`username`) USING BTREE,
  KEY `FK97BBABC3C80E875F` (`organization_id`) USING BTREE,
  CONSTRAINT `FK97BBABC3C80E875F` FOREIGN KEY (`organization_id`) REFERENCES `base_organization` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

/*Table structure for table `base_user_role` */

CREATE TABLE `base_user_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `priority` int(11) NOT NULL,
  `role_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK24086F723FFD717F` (`role_id`) USING BTREE,
  KEY `FK24086F72E528355F` (`user_id`) USING BTREE,
  CONSTRAINT `FK24086F723FFD717F` FOREIGN KEY (`role_id`) REFERENCES `base_role` (`id`),
  CONSTRAINT `FK24086F72E528355F` FOREIGN KEY (`user_id`) REFERENCES `base_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

/*Table structure for table `brand_organization` */

CREATE TABLE `brand_organization` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '序列',
  `brand_id` varchar(50) DEFAULT NULL COMMENT '品牌编号',
  `brand_Name` varchar(100) DEFAULT NULL COMMENT '品牌名称',
  `organization_id` int(11) DEFAULT NULL COMMENT '所属组织',
  `organization_name` varchar(100) DEFAULT NULL COMMENT '所属组织名称',
  `remarks` varchar(1000) DEFAULT NULL COMMENT '备注',
  `updatetime` varchar(100) DEFAULT NULL COMMENT '数据更新时间',
  `reserve1` varchar(100) DEFAULT NULL COMMENT '预留字段1',
  `reserve2` varchar(100) DEFAULT NULL COMMENT '预留字段2',
  `reserve3` varchar(100) DEFAULT NULL COMMENT '预留字段3',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

/*Table structure for table `brands_info` */

CREATE TABLE `brands_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `brand_name` varchar(100) DEFAULT NULL COMMENT '品牌名称',
  `area_id` bigint(20) DEFAULT NULL COMMENT '地区编号',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `update_time` datetime DEFAULT NULL COMMENT '数据更新时间',
  PRIMARY KEY (`id`),
  KEY `FK_Reference_8` (`area_id`),
  CONSTRAINT `FK_Reference_8` FOREIGN KEY (`area_id`) REFERENCES `area_info` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COMMENT='品牌表';

/*Table structure for table `cell_month_summary_info` */

CREATE TABLE `cell_month_summary_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `sales_cell_summary_id` bigint(20) DEFAULT NULL COMMENT '销售单列记录合计表ID',
  `brand_id` bigint(20) DEFAULT NULL COMMENT '品牌编号',
  `brand_name` varchar(25) DEFAULT NULL COMMENT '品牌名字',
  `finance_costs_type_id` bigint(20) DEFAULT NULL COMMENT '财务费用大类别',
  `finance_costs_type_name` varchar(100) DEFAULT NULL COMMENT '财务费用大类别名称',
  `finance_costs_categories_id` bigint(20) DEFAULT NULL COMMENT '财务费用小类别',
  `finance_costs_categories_name` varchar(100) DEFAULT NULL COMMENT '财务费用小类别名称',
  `month_summary_amount` decimal(20,2) DEFAULT NULL COMMENT '月汇总金额',
  `summary_time` datetime DEFAULT NULL COMMENT '汇总时间',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `update_time` datetime DEFAULT NULL COMMENT '数据更新时间',
  PRIMARY KEY (`id`),
  KEY `FK_Reference_11` (`brand_id`),
  KEY `FK_Reference_6` (`sales_cell_summary_id`),
  CONSTRAINT `FK_Reference_11` FOREIGN KEY (`brand_id`) REFERENCES `brands_info` (`id`),
  CONSTRAINT `FK_Reference_6` FOREIGN KEY (`sales_cell_summary_id`) REFERENCES `cell_summary_info` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10507 DEFAULT CHARSET=utf8 COMMENT='品牌月列汇总表';

/*Table structure for table `cell_summary_info` */

CREATE TABLE `cell_summary_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `finance_costs_type_name` varchar(100) DEFAULT NULL COMMENT '财务费用大类别名称',
  `finance_costs_type_id` bigint(20) DEFAULT NULL COMMENT '财务费用大类别',
  `finance_costs_categories_name` varchar(100) DEFAULT NULL COMMENT '财务费用小类别名称',
  `finance_costs_categories_id` bigint(20) DEFAULT NULL COMMENT '财务费用小类别',
  `summary_type` int(11) DEFAULT NULL COMMENT '总计类型(1:行总计2: all总计)',
  `project_subtotal` decimal(20,2) DEFAULT NULL COMMENT '项目小计',
  `comprehensive_cost` decimal(20,2) DEFAULT NULL COMMENT '综合费用',
  `current_summary` decimal(20,2) DEFAULT NULL COMMENT '本期合计',
  `chain` decimal(20,2) DEFAULT NULL COMMENT '环比',
  `pre_summary` decimal(20,2) DEFAULT NULL COMMENT '上期合计',
  `pre_year_ago` decimal(20,2) DEFAULT NULL COMMENT '上年同期',
  `year_rate` decimal(20,2) DEFAULT NULL COMMENT '同比',
  `summary_time` datetime DEFAULT NULL COMMENT '汇总时间',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `update_time` datetime DEFAULT NULL COMMENT '数据更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=511 DEFAULT CHARSET=utf8 COMMENT='汇总列合计表';

/*Table structure for table `classify_info` */

CREATE TABLE `classify_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `classify_type` varchar(255) DEFAULT NULL COMMENT '分类类型',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `update_time` datetime DEFAULT NULL COMMENT '数据更新时间',
  `finance_costs_categories_id` bigint(20) DEFAULT NULL COMMENT '财务二级分类ID',
  PRIMARY KEY (`id`),
  KEY `finance_costs_categories_id` (`finance_costs_categories_id`),
  CONSTRAINT `classify_info_ibfk_1` FOREIGN KEY (`finance_costs_categories_id`) REFERENCES `finance_costs_categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8 COMMENT='分类';

/*Table structure for table `classify_info_two` */

CREATE TABLE `classify_info_two` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `classify_type` varchar(255) DEFAULT NULL COMMENT '分类类型',
  `classify_id` varchar(100) DEFAULT NULL COMMENT '分类编码',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `classify_info_id` bigint(20) DEFAULT NULL COMMENT '大分类ID',
  `update_time` datetime DEFAULT NULL COMMENT '数据更新时间',
  PRIMARY KEY (`id`),
  KEY `FK_Reference_3` (`classify_info_id`),
  CONSTRAINT `FK_Reference_3` FOREIGN KEY (`classify_info_id`) REFERENCES `classify_info` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=191 DEFAULT CHARSET=utf8 COMMENT='二级小分类';

/*Table structure for table `finance_costs_categories` */

CREATE TABLE `finance_costs_categories` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `cost_type` varchar(255) DEFAULT NULL COMMENT '费用类型',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `finance_costs_id` bigint(20) DEFAULT NULL COMMENT '大分类ID',
  `update_time` datetime DEFAULT NULL COMMENT '数据更新时间',
  PRIMARY KEY (`id`),
  KEY `FK_Reference_7` (`finance_costs_id`),
  CONSTRAINT `FK_Reference_7` FOREIGN KEY (`finance_costs_id`) REFERENCES `finance_costs_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='财务费用类别-二级小类';

/*Table structure for table `finance_costs_type` */

CREATE TABLE `finance_costs_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `cost_type` varchar(255) DEFAULT NULL COMMENT '费用类型',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `update_time` datetime DEFAULT NULL COMMENT '数据更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COMMENT='财务费用类别';

/*Table structure for table `finance_file_info` */

CREATE TABLE `finance_file_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `file_relative_path` varchar(1000) DEFAULT NULL COMMENT '保存相对路径',
  `file_name` varchar(255) DEFAULT NULL COMMENT '文件名',
  `user_name` varchar(25) DEFAULT NULL COMMENT '用户名',
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户ID',
  `user_adderss` varchar(100) DEFAULT NULL COMMENT '用户IP',
  `import_time` date DEFAULT NULL COMMENT '导入时间',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `update_time` datetime DEFAULT NULL COMMENT '数据更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_import_time` (`import_time`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COMMENT='原始文件记录表';

/*Table structure for table `finance_file_log_info` */

CREATE TABLE `finance_file_log_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `session_id` varchar(255) DEFAULT NULL COMMENT 'sessionid',
  `user_name` varchar(25) DEFAULT NULL COMMENT '用户名',
  `message` varchar(255) DEFAULT NULL COMMENT '提示消息',
  `message_level` varchar(25) DEFAULT NULL COMMENT '消息级别',
  `message_status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户ID',
  `user_address` varchar(100) DEFAULT NULL COMMENT '用户IP',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `update_time` datetime DEFAULT NULL COMMENT '数据更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_time_sessionid` (`session_id`,`user_name`,`update_time`)
) ENGINE=InnoDB AUTO_INCREMENT=4148 DEFAULT CHARSET=utf8 COMMENT='导入文件日志表';

/*Table structure for table `row_month_summary_info` */

CREATE TABLE `row_month_summary_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `brand_id` bigint(20) DEFAULT NULL COMMENT '品牌编号',
  `row_summary_info_id` bigint(20) DEFAULT NULL COMMENT '汇总行_id',
  `brand_name` varchar(25) DEFAULT NULL COMMENT '品牌名字',
  `classify_id` bigint(20) DEFAULT NULL COMMENT '分类大类别',
  `classify_name` varchar(100) DEFAULT NULL COMMENT '分类大类别名称',
  `classify_info_two_id` bigint(20) DEFAULT NULL COMMENT '分类小类别',
  `classify_info_two_name` varchar(100) DEFAULT NULL COMMENT '分类小类别名称',
  `month_summary_amount` decimal(20,2) DEFAULT NULL COMMENT '月汇总金额',
  `summary_time` datetime DEFAULT NULL COMMENT '汇总时间',
  `business_income_type` int(11) DEFAULT NULL COMMENT '营业收入类型(1:营业收入,2:其它)',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `update_time` datetime DEFAULT NULL COMMENT '数据更新时间',
  PRIMARY KEY (`id`),
  KEY `FK_Reference_9` (`brand_id`),
  KEY `row_summary_info_id` (`row_summary_info_id`),
  CONSTRAINT `row_month_summary_info_ibfk_1` FOREIGN KEY (`row_summary_info_id`) REFERENCES `row_summary_info` (`id`),
  CONSTRAINT `FK_Reference_9` FOREIGN KEY (`brand_id`) REFERENCES `brands_info` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=97042 DEFAULT CHARSET=utf8 COMMENT='品牌月行汇总表';

/*Table structure for table `row_summary_info` */

CREATE TABLE `row_summary_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `project_id` varchar(100) DEFAULT NULL COMMENT '项目编号',
  `classify_id` bigint(20) DEFAULT NULL COMMENT '分类大类别',
  `classify_name` varchar(100) DEFAULT NULL COMMENT '分类大类别名称',
  `classify_info_two_id` bigint(20) DEFAULT NULL COMMENT '分类小类别',
  `classify_info_two_name` varchar(100) DEFAULT NULL COMMENT '分类小类别名称',
  `project_subtotal` decimal(20,2) DEFAULT NULL COMMENT '项目小计',
  `comprehensive_cost` decimal(20,2) DEFAULT NULL COMMENT '综合费用',
  `current_summary` decimal(20,2) DEFAULT NULL COMMENT '本期合计',
  `chain` decimal(20,2) DEFAULT NULL COMMENT '环比',
  `pre_summary` decimal(20,2) DEFAULT NULL COMMENT '上期合计',
  `pre_year_ago` decimal(20,2) DEFAULT NULL COMMENT '上年同期',
  `year_rate` decimal(20,2) DEFAULT NULL COMMENT '同比',
  `sales_cell_summary_id` bigint(20) DEFAULT NULL COMMENT '列汇总表id',
  `summary_time` datetime DEFAULT NULL COMMENT '汇总时间',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `update_time` datetime DEFAULT NULL COMMENT '数据更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4806 DEFAULT CHARSET=utf8 COMMENT='汇总行合计表';

/*Table structure for table `row_summary_info_copy` */

CREATE TABLE `row_summary_info_copy` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `project_id` varchar(100) DEFAULT NULL COMMENT '项目编号',
  `classify_id` bigint(20) DEFAULT NULL COMMENT '分类大类别',
  `classify_name` varchar(100) DEFAULT NULL COMMENT '分类大类别名称',
  `classify_info_two_id` bigint(20) DEFAULT NULL COMMENT '分类小类别',
  `classify_info_two_name` varchar(100) DEFAULT NULL COMMENT '分类小类别名称',
  `project_subtotal` decimal(20,2) DEFAULT NULL COMMENT '项目小计',
  `comprehensive_cost` decimal(20,2) DEFAULT NULL COMMENT '综合费用',
  `current_summary` decimal(20,2) DEFAULT NULL COMMENT '本期合计',
  `chain` decimal(20,2) DEFAULT NULL COMMENT '环比',
  `pre_summary` decimal(20,2) DEFAULT NULL COMMENT '上期合计',
  `pre_year_ago` decimal(20,2) DEFAULT NULL COMMENT '上年同期',
  `year_rate` decimal(20,2) DEFAULT NULL COMMENT '同比',
  `sales_cell_summary_id` bigint(20) DEFAULT NULL COMMENT '列汇总表id',
  `summary_time` datetime DEFAULT NULL COMMENT '汇总时间',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `update_time` date DEFAULT NULL COMMENT '数据更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3636 DEFAULT CHARSET=utf8 COMMENT='汇总行合计表';

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
